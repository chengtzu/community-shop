<?php

namespace app\api\controller;

use app\BaseController;

class Page extends BaseController
{

}