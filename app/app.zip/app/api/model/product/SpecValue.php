<?php

namespace app\api\model\product;

use app\common\model\product\SpecValue as SpecValueModel;

class SpecValue extends SpecValueModel
{

}