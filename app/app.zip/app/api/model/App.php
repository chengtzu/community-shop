<?php

namespace app\api\model;

use app\common\model\app\App as AppModel;

/**
 * 微信小程序模型
 */
class App extends AppModel
{

}