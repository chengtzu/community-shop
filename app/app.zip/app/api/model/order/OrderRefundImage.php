<?php

namespace app\api\model\order;

use app\common\model\order\OrderRefundImage as OrderRefundImageModel;

/**
 * 售后单图片模型
 */
class OrderRefundImage extends OrderRefundImageModel
{

}