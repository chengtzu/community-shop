<?php

namespace app\shop\model\product;

use app\common\model\product\ProductSpecRel as ProductSpecRelModel;

/**
 * 产品规格关系模型
 */
class ProductSpecRel extends ProductSpecRelModel
{
}
