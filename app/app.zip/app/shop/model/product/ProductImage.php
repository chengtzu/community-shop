<?php

namespace app\shop\model\product;

use app\common\model\product\ProductImage as ProductImageModel;

/**
 * 产品图片模型
 */
class ProductImage extends ProductImageModel
{

}
