<?php

namespace app\shop\model\order;

use app\common\model\order\OrderProduct as OrderProductModel;

/**
 * 订单商品模型
 */
class OrderProduct extends OrderProductModel
{

}