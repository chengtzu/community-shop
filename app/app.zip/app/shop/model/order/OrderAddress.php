<?php

namespace app\shop\model\order;

use app\common\model\OrderAddress as OrderAddressModel;

/**
 * 订单地址模型
 */
class OrderAddress extends OrderAddressModel
{

}