<?php

namespace app\shop\model\settings;

use app\common\model\settings\Region as RegionModel;

/**
 * 地区模型
 */
class Region extends RegionModel
{

}
